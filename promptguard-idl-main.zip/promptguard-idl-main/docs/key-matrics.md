# Key design metrics
We compose the key design metrics here for ease of reference.

TODO...
- Kafka sizing
- Redis sizing
- Each components sizing

TODO...
Make decision if we should put them separately